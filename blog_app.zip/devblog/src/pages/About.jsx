const About = () => {
  return (
    <div className="page">
      <div className="about-box">
        <h2>About DevBlog</h2>
        <p>
          DevBlog is a practice project built for the MERN Stack Development Workshop 2026, run by
          the Hayatian Computing Society at the University of Gujrat. It brings together MongoDB,
          Express, React, useEffect, axios and React Router to build a small blog where posts live
          in a database instead of being hardcoded into components.
        </p>
      </div>
    </div>
  );
};

export default About;
