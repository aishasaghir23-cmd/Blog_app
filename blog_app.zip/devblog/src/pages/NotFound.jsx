import { Link } from "react-router-dom";

const NotFound = () => {
  return (
    <div className="page">
      <div className="not-found">
        <h2>404</h2>
        <p>This page does not exist.</p>
        <Link to="/" className="cta-btn">
          Go back home
        </Link>
      </div>
    </div>
  );
};

export default NotFound;
