# DevBlog

A small blog built with MongoDB, Express, React, useEffect, axios and React Router.
Built for the MERN Stack Development Workshop 2026 (Week 5 project) — Hayatian Computing Society, University of Gujrat.

## What it does

Blog posts live in MongoDB. An Express API serves them as JSON. React fetches them with
`useEffect` and `axios`, and React Router splits the site into pages with clean URLs
(`/`, `/posts`, `/posts/:id`, `/new`, `/about`, plus a 404 catch-all).

## Project structure

```
devblog/
├── server/              # Express + MongoDB API
│   ├── models/Post.js
│   ├── db.js
│   ├── seed.js
│   ├── index.js
│   └── .env
├── src/                 # React app (Vite)
│   ├── components/
│   ├── pages/
│   ├── api.js
│   ├── App.jsx
│   ├── main.jsx
│   └── styles.css
├── screenshots/
└── README.md
```

## Running it locally

**Terminal 1 — backend**

```bash
cd server
npm install
npm run seed     # only the first time, fills MongoDB with 6 sample posts
npm start        # http://localhost:3000
```

**Terminal 2 — frontend**

```bash
npm install
npm run dev       # http://localhost:5173
```

Make sure MongoDB is running locally (or set `MONGO_URI` in `server/.env` to an Atlas
connection string) before starting the server.

## API routes

| Method | Route            | What it does                     |
|--------|------------------|-----------------------------------|
| GET    | /api/posts       | all posts, newest first           |
| GET    | /api/posts/:id   | one post                          |
| POST   | /api/posts       | create a new post                 |
| DELETE | /api/posts/:id   | delete a post                     |

## Screenshots

| Home | Posts |
|------|-------|
| ![Home](screenshots/home.png) | ![Posts](screenshots/posts.png) |

| Post detail | New post |
|-------------|----------|
| ![Post detail](screenshots/post-detail.png) | ![New post](screenshots/new-post.png) |

## Notes

- `.env` and `node_modules/` are git-ignored and never pushed.
- The seed script clears the `posts` collection before inserting sample data — only run it
  against a database you don't mind wiping.

---
Instructor: Kamran Ahsan | Hayatian Computing Society | University of Gujrat | Workshop Session 2026
